package multi.com.f.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import multi.com.f.dto.MemberDto;
import multi.com.f.service.MemberService;

@RestController
public class MemberController {

	@Autowired
	MemberService service;
	
	@RequestMapping(value = "/allMember")
	public List<MemberDto> allMem(){
		System.out.println("MemberController allMem() " + new Date());
		
		return service.allmember();
	}
	
}
